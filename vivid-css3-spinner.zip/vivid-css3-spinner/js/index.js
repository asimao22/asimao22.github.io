/* 
Vivid CSS3 Spinner
Made by Kevin Jannis (@kevinjannis)
Inspired by http://gif.flrn.nl/post/111106392227
View more at www.janniskev.in
*/